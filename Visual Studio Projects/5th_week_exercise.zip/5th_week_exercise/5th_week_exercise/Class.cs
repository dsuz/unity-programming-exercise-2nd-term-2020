﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// ========== このファイルにはクラスを定義する ==========

/// <summary>
/// Item クラスは以下のように定義せよ。
/// - string 型のメンバ変数 name を持つ
/// - コンストラクタはどのようなものでもよい
/// - Use メソッドを実装する。Use メソッドは呼ばれると、「〇〇（アイテム名）を使った」と Console に出力する（例：「魔法の鍵を使った」。戻り値は返さない(void)。
/// </summary>
class Item
{
    string name;
}

/// <summary>
/// Vector2 クラスは以下のように定義せよ。
/// - float 型のメンバ変数 x, y を持つ
/// - デフォルトコンストラクタにより (0, 0) が作られる
/// - パラメータ付きコンストラクタにより (x, y) を指定してインスタンスを生成する
/// - 2点間の距離を求める関数 Distance を実装する。Distance 関数は Vector2 型のパラメータを受け取り、受け取った座標との距離を返す。
/// - ToString 関数を実装する。ToString 関数は Vector2 を "(x, y)" の形式の文字列を返す。
/// </summary>
class Vector2
{

}

class Vector3
{
    // メンバ変数
    public float x;
    public float y;
    public float z;

    /// <summary>
    /// デフォルトコンストラクタ（引数なしのコンストラクタ）
    /// (0, 0, 0) を生成する
    /// </summary>
    public Vector3()
    {
        x = 0f;
        y = 0f;
        z = 0f;
    }

    /// <summary>
    /// コンストラクタ
    /// パラメータを受け取って、それを元にインスタンスを作る
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="z"></param>
    public Vector3(float x, float y, float z)
    {
        this.x = x; // パラメータで受け取った x と、このクラスのメンバ変数 x を区別するために this キーワードを使っている
        this.y = y;
        this.z = z;
    }

    /// <summary>
    /// パラメータで指定された target との距離を求める
    /// </summary>
    /// <param name="target"></param>
    /// <returns></returns>
    public float Distance(Vector3 target)
    {
        // このインスタンス (this) と target の距離を求めて返す
        float distance = (float)Math.Sqrt(Math.Pow(this.x - target.x, 2) + Math.Pow(this.y - target.y, 2) + Math.Pow(this.z - target.z, 2));
        return distance;
    }

    /// <summary>
    /// 文字列に変換する
    /// </summary>
    /// <returns></returns>
    public string ToString()
    {
        string message = "(" + this.x + ", " + this.y + ", " + this.z + ")";
        return message;
    }
}

class Person
{
    public string name;
    Gender gender;
    DateTime birthday;
    BloodType bloodType;

    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="name"></param>
    /// <param name="gender"></param>
    /// <param name="birthday"></param>
    /// <param name="bloodType"></param>
    public Person(string name, Gender gender, DateTime birthday, BloodType bloodType)
    {
        this.name = name;
        this.gender = gender;
        this.birthday = birthday;
        this.bloodType = bloodType;
    }

    public int GetAge()
    {
        DateTime today = DateTime.Today;
        int age = (int.Parse(today.ToString("yyyyMMdd")) - int.Parse(birthday.ToString("yyyyMMdd"))) / 10000;
        return age;
    }
}

/// <summary>
/// 性別を表す列挙型
/// </summary>
enum Gender
{
    Male,
    Female,
    Mics,
}

/// <summary>
/// 血液型を表す列挙型
/// </summary>
enum BloodType
{
    A,
    B,
    O,
    AB,
}