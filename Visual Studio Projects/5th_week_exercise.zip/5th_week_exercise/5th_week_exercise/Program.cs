﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Exercise01();
        //Exercise02();
        //Exercise03();
        //Exercise04();

        Console.Write("\r\nHit any key...\r\n");
        Console.ReadKey(true); // 何かキーを押すまで抜けないために書いている
    }

    /// <summary>
    /// （例題）Vector3 クラスを定義し、Vector3 型のインスタンス変数 v0, v1 を宣言して v0, v1 間の距離を求め、画面に表示せよ。
    /// </summary>
    static void Exercise01()
    {
        Vector3 v0 = new Vector3();   // 新しく変数を宣言する時は new キーワードを使う
        Console.WriteLine("v0: {0}", v0.ToString());
        Vector3 v1 = new Vector3(-2f, -4f, 5f);
        Console.WriteLine("v1: {0}", v1.ToString());

        float d = v0.Distance(v1);
        Console.Write("距離: {0}", d);
    }

    /// <summary>
    /// Vector2 クラスを定義し、Vector2 型のインスタンス変数 v0, v1 を宣言して値を生成し、v0, v1 間の距離を求めて画面に表示せよ。
    /// </summary>
    static void Exercise02()
    {
    }

    /// <summary>
    /// Person クラスに ToString 関数を実装せよ。
    /// ToString 関数は以下の情報を文字列として返す。
    /// - 名前
    /// - 性別
    /// - 誕生日
    /// - 血液型
    /// ヒント: 日時（DateTimeオブジェクト）を文字列に変換する https://dobon.net/vb/dotnet/string/datetimeformat.html
    /// </summary>
    static void Exercise03()
    {
        DateTime birthday = new DateTime(1992, 9, 5);
        Person p = new Person("Taro Yamada", Gender.Male, birthday, BloodType.B);
        Console.WriteLine(p.name + " の年齢は " + p.GetAge());
        Console.WriteLine(p.ToString());    // この状態でも ToString 関数は呼べるのだが、適切な結果を返さない
    }

    /// <summary>
    /// Class.cs に Item クラスを定義せよ。Item クラスの仕様は Class.cs の該当箇所を参照せよ。
    /// Item クラスが定義できたら、以下で次の処理をせよ。
    /// 新しい Item クラスの変数を宣言し、name を「薬草」とせよ。そして Use 関数を呼べ。
    /// </summary>
    static void Exercise04()
    {
    }
}
