﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Exercise07();   // やさしい
        //Exercise08();
        //Exercise09();
        //Exercise10();
        //Exercise11();
        //Exercise12(); // 難しい

        Console.Write("\r\nHit any key...\r\n");
        Console.ReadKey(true); // 何かキーを押すまで抜けないために書いている
    }

    /// <summary>
    /// （解答済み例題）整数の２乗を計算する関数 Square を定義せよ。Square は int 型の引数を一つ受け取り、結果を int 型の戻り値として返すこと。
    /// そして、その関数を呼び出すプログラムを作り、動作を確認せよ。
    /// </summary>
    static void Exercise07()
    {
        for (int i = 2; i < 10; i++)
        {
            int result = Square(i);
            Console.WriteLine("{0} * {0} = {1}", i, result);
        }
    }

    static int Square(int x)
    {
        return x * x;
    }

    /// <summary>
    /// ２つ整数の平均値を計算する関数 Average を定義せよ。Average は int 型の引数を２つ受け取り、結果を int 型の戻り値として返すこと。
    /// そして、その関数を呼び出すプログラムを作り、動作を確認せよ。
    /// </summary>
    static void Exercise08()
    {
        int x = 12344564;
        Console.Write(x);
    }

    /// <summary>
    /// ２つの整数の大きい方を返す関数 Max を定義せよ。Max は int 型の引数を２つ受け取り、大きい方の値を戻り値として返すこと。
    /// この関数 Max を使って、int 型の引数を３つ受け取り、それらのうち最大のものを返す関数 Max を定義せよ。
    /// 後者の Max を呼び出すプログラムを作り、動作を確認せよ。
    /// </summary>
    static void Exercise09()
    {
        int x = 12344564;
        Console.Write(x);
    }

    /// <summary>
    /// 九九のひとつの段を出力する関数 Kuku を定義せよ。Kuku は int 型の引数を１つ受け取り、その段を文字列として出力する。
    /// 例）引数が 7 だったら、九九の７の弾を出力する。
    /// この関数を使って、九九の表を出力せよ。
    /// </summary>
    static void Exercise10()
    {
        int x = 12344564;
        Console.Write(x);
    }

    /// <summary>
    /// ある数が素数かどうかを判定する関数 IsPrime を定義せよ。IsPrime は int 型の引数を一つ受け取り、受け取った引数が素数ならば true を、合成数ならば false を返す。
    /// 例）引数として 3 を与えると true、8 を与えると false を返す。
    /// この関数を使って、100 未満の素数を全て出力するプログラムを作れ。
    /// </summary>
    static void Exercise11()
    {
        for (int i = 2; i < 100; i++)
        {
            if (IsPrime(i))
            {
                Console.WriteLine(i.ToString());
            }
        }
    }

    /// <summary>
    /// 素数を判定するアルゴリズムは「エラトステネスのふるい」を使うこと。
    /// </summary>
    /// <param name="n"></param>
    /// <returns></returns>
    static bool IsPrime(int n)
    {
        // n が素数なら true, 合成数なら false を返す
        return true;
    }
}
