﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Item
{
    public string name;

    // 引数付きコンストラクタ
    public Item(string name)
    {
        this.name = name;
    }

    public void Use()
    {
        Console.WriteLine(name + "を使った");
    }
}

/// <summary>
/// Potion は派生クラス、Item は基底クラス
/// </summary>
class Potion : Item
{
    // デフォルトコンストラクタ
    public Potion() : base("ポーション") // 基底クラスのコンストラクタを呼び出している
    {
    }

    public void Drink()
    {
        Console.WriteLine(this.name + "を飲んだ");  // 基底クラスのメンバ変数にアクセスしている
    }
}

class Creature
{
    public void Walk()
    {
        Console.WriteLine("歩いた");
    }
}

class Human
{
    public void Greet()
    {
        Console.WriteLine("こんにちは");
    }
}

class Person
{
    public string name;

    public Person(string name)
    {
        this.name = name;
    }

    public void Introduce()
    {
        Console.WriteLine("私の名前は{0}です。", this.name);
    }
}

class Student : Person
{
    public int id;

    public Student(string name, int id): base(name)
    {
        this.id = id;
    }

    public new void Introduce()
    {
        base.Introduce();
        Console.WriteLine("学籍番号は{0}です。", this.id);
    }
}

class Player
{
    public string Name;

    public Player(string name)
    {
        Name = name;
    }

    //　Attackメソッドはオーバーライドされる
    public void Attack(string enemy)
    {
        Console.WriteLine(Name + "は" + enemy + "を攻撃した");
    }
}

//　Playerクラスを継承する
class Wizard
{
    public Wizard(string name)
    {
    }

    //　Attackメソッドをオーバーライドする
    public void Attack(string enemy)
    {
        Console.WriteLine("ズバーン");
    //    Console.WriteLine(Name + "は" + enemy + "に炎を放った"); // この行はアンコメントすること
    }
}
