﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Exercise05();
        // Exercise06();
        Exercise07();
        // Exercise08();

        Console.Write("\r\nHit any key...\r\n");
        Console.ReadKey(true); // 何かキーを押すまで抜けないために書いている
    }

    /// <summary>
    /// テーマ：継承
    /// Item クラスを継承して Potion クラスを作り、基底クラスと派生クラスの関数を呼べ。
    /// また、Item クラスをそのままインスタンス化し、メンバ関数を呼べ。
    /// </summary>
    static void Exercise05()
    {
        Console.WriteLine("Exercise05");
        Potion p = new Potion();
        p.Use();    // 基底クラスの関数を呼んでいる
        p.Drink();  // 派生クラスの関数を呼んでいる
        Item i = new Item("薬草");
        i.Use();
    }

    /// <summary>
    /// テーマ：継承
    /// Creature クラスを継承して Human クラスを作り、Human.Greet 関数と Creature.Walk 関数を呼べ。
    /// </summary>
    static void Exercise06()
    {
        Human h = new Human();
        h.Greet();
        // h.Walk();    // Human に Creature を継承させ、この行のコンパイルエラーを解決せよ。
    }

    /// <summary>
    /// 基底クラス Person、派生クラス Student の Introduce 関数をそれぞれ呼べ。
    /// </summary>
    static void Exercise07()
    {
        Console.WriteLine("Exercise07");
        Student s = new Student("Taro Yamada", 1);
        Console.WriteLine("=== Student.Introduce() を呼ぶ ===");
        s.Introduce();
        Console.WriteLine("=== Person.Introduce() を呼ぶ ===");
        ((Person)s).Introduce();
    }

    /// <summary>
    /// Playerクラスを継承したWizardクラスを作成し、Attackメソッドをオーバーライドさせ、
    /// 下の期待する出力値と同じ出力を得よ。
    /// === パーティーでスライムと戦う ===
    /// 勇者はスライムを攻撃した
    /// 戦士はスライムを攻撃した
    /// ズバーン
    /// 魔法使いはスライムに炎を放った
    /// </summary>
    public static void Exercise08()
    {
        Console.WriteLine("=== パーティーでスライムと戦う ===");
        var hero = new Player("勇者");
        var warrior = new Player("戦士");
        var wizard = new Wizard("魔法使い");

        // 以下の行はアンコメントすること (Ctrl + K -> Ctrl + U)
        //Player[] party = { hero, warrior, wizard };

        //foreach (var player in party)
        //{
        //    player.Attack("スライム");
        //}
    }
}
